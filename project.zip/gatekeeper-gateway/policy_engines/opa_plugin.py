from unittest import result
import requests
from policy_engines.base import PolicyEnginePlugin

class OPAPlugin(PolicyEnginePlugin):
    def __init__(self, opa_url):
        self.opa_url = opa_url
    
    def evaluate(self, context: dict, action: str, resource: str, **kwargs) -> dict:
        payload = {
            "input": {
                "context": context,
                "action": action,
                "resource": resource,
                **kwargs
            }
        }
        
        try:
            resp = requests.post(self.opa_url, json=payload, timeout=2)
            resp.raise_for_status()
            result = resp.json()
            # Add this to the OPAPlugin.evaluate method after resp.json():
            print(f"OPA Response: {result}", flush=True)
            
            # Handle different OPA response formats
            opa_result = result.get("result")
            
            if isinstance(opa_result, bool):
                # Simple boolean response
                allow = opa_result
                reason = "Allowed by policy" if allow else "Denied by policy"
            elif isinstance(opa_result, dict):
                # Complex response with allow/reason/deny_reason
                allow = opa_result.get("allow", False)
                # Handle both "reason" and "deny_reason" from OPA policies
                reason = (opa_result.get("reason") or 
                         opa_result.get("deny_reason") or 
                         ("Denied by policy" if not allow else "Allowed by policy"))
            else:
                # Unexpected format - default to deny
                allow = False
                reason = f"Unexpected OPA response format: {opa_result}"
            
            return {"allow": allow, "reason": reason}
            
        except requests.exceptions.RequestException as ex:
            return {"allow": False, "reason": f"OPA connection error: {ex}"}
        except Exception as ex:
            return {"allow": False, "reason": f"OPA error: {ex}"}