# MCP Client

Example script to send MCP commands to the gateway.
