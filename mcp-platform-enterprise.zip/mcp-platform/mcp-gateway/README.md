# MCP Gateway

Features:
- Plugin-based architecture
- Enterprise OPA policy-as-code integration
- Auth, RBAC, PII, WAF, signature verification, prompt safety, rate limiting plugins
- Observability (logging/metrics/tracing)
- Tool registry and signatures
