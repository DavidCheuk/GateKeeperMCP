# MCP Platform (Enterprise-Ready, OPA Integrated)

See mcp-gateway/README.md for details.
