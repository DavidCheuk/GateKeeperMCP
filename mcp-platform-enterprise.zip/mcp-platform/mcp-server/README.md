# MCP Server

Dummy server to receive and execute MCP commands.
